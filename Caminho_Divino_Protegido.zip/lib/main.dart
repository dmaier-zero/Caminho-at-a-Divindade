
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'src/app.dart'; // Supondo que CaminhoDivinoApp está aqui

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final packageInfo = await PackageInfo.fromPlatform();
  const pacoteAutorizado = "com.pablosedlmaier.caminhodivino"; // Substitua se necessário

  if (packageInfo.packageName != pacoteAutorizado) {
    runApp(AntiPiracyApp());
  } else {
    runApp(CaminhoDivinoApp());
  }
}

class AntiPiracyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text(
            "Erro de autenticação\nVersão não autorizada.",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.red, fontSize: 24),
          ),
        ),
      ),
    );
  }
}
