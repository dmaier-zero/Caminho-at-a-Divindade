Projeto Caminho Divino - Desenvolvido por Pablo Sedlmaier
Para rodar: abrir no Acode, configurar Termux e executar build apk